package main

import (
	"fmt"
	"google.golang.org/grpc"
	deliveryGRPC "hashChallenger/delivery/grpc"
	"hashChallenger/resource/config"
	"hashChallenger/resource/database/mongoDB"
	"hashChallenger/resource/injection"
	"log"
	"net"
)

var cfg config.Config

func init() {
	cfg = config.NewViperConfig()
	mongoDB.MongoDBConnect(cfg.GetString("database.mongodb.url"))
	injection.Inject()

}
func main() {

	serverAddress := cfg.GetString("server.address")

	list, err := net.Listen("tcp", serverAddress)
	if err != nil {
		log.Printf(`ERROR:[%s]`,err.Error())
		panic("Something got wrong")
	}

	useCase := injection.Usecase
	server := grpc.NewServer()
	deliveryGRPC.NewProductServerGrpc(server,useCase)

	fmt.Println("Server Run at ", serverAddress)

	err = server.Serve(list)
	if err != nil {
		fmt.Println("Unexpected Error", err)
	}

}
