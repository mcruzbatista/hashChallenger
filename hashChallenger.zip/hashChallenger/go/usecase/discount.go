package usecase

import (
	"hashChallenger/model"
	"time"
)

func applyDiscount(user *model.User, product *model.Product) *model.Product {
	var pctAmount int64 = 0
	//Check if is birthday

	if user.DateOfBirth.Month() == time.Now().Month() && user.DateOfBirth.Day() == time.Now().Day() {
		pctAmount += 500
	}
	//Check if is blackFriday
	if time.Now().Month() == time.November && time.Now().Day() == 25 {
		pctAmount += 1000
	}

	if pctAmount > 1000 {
		pctAmount = 1000
	}

	return calculateProductDiscount(pctAmount,product)
}

func calculateProductDiscount(pctAmount int64,product *model.Product) *model.Product{

	discValue := (product.PrinceInCents * (pctAmount/100)) / 100

	product.Discount.Pct = pctAmount
	product.Discount.ValueInCents = product.PrinceInCents - discValue

	return product
}