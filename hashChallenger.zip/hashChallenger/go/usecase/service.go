package usecase

import (
	"github.com/globalsign/mgo/bson"
	"hashChallenger/model"
	"hashChallenger/repository"
)

type ProductUsecase interface {
	GetProductByIdAndUserId(productId, userId string) ([]*model.Product, error)
}

type productResource struct {
	productRepo repository.ProductRepository
	userRepo    repository.UserRepository
}

func (sr *productResource) GetProductByIdAndUserId(productId, userId string) ([]*model.Product, error) {

	if productId == "" && userId == "" {
		return nil, model.ERROR_EMPTY_VALUES
	}else if !bson.IsObjectIdHex(userId) {
		return nil, model.ERROR_INVALID_VALUE
	}

	//todo: make both call async
	prodList, err := sr.productRepo.FindProductById(productId)

	if err != nil {
		return nil, err
	}

	user, err := sr.userRepo.FindUserById(userId)

	if err != nil {
		return nil, err
	}

	for i, prod := range prodList {
		discProd := applyDiscount(user,prod)
		prodList[i] = discProd
	}


	return prodList,nil
}

func NewProductService(pr repository.ProductRepository, ur repository.UserRepository) ProductUsecase {
	return &productResource{
		productRepo:pr,
		userRepo:ur,
	}
}
