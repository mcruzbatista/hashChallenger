package usecase

import (
	"github.com/bouk/monkey"
	"github.com/globalsign/mgo/bson"
	"github.com/stretchr/testify/assert"
	"hashChallenger/model"
	"testing"
	"time"
)

func TestCalculateProductDiscount(t *testing.T) {
	//setup
	var pct int64 = 1000
	product := NewProductWithoutDiscount()

	//act
	product = calculateProductDiscount(pct,product)

	//assert
	assert.NotNil(t,product.Discount.ValueInCents)
	assert.NotNil(t,product.Discount.Pct)
	assert.NotNil(t,int64(1000),product.Discount.Pct,"Expect that product should be equal to expected")
	assert.Equal(t,int64(90000),product.Discount.ValueInCents,"Expect that value with product should be equal to expected")
}

func TestCalculateProductDiscount_WhenPctIsZero(t *testing.T) {
	//setup
	var pct int64 = 0
	product := NewProductWithoutDiscount()

	//act
	product = calculateProductDiscount(pct,product)

	//assert
	assert.NotNil(t,product.Discount.ValueInCents)
	assert.NotNil(t,product.Discount.Pct)
	assert.NotNil(t,int64(0),product.Discount.Pct,"Expect that product should be equal to expected")
	assert.Equal(t,int64(100000),product.Discount.ValueInCents,"Expect that value with product should be equal to expected")
}

func TestApplyDiscount_WhenIsUserBirthday(t *testing.T) {
	user := NewUser(time.Now())
	product := NewProductWithoutDiscount()

	discProduct := applyDiscount(user,product)

	assert.Equal(t,int64(500),discProduct.Discount.Pct, "Discount should be 5% because is User Birthday")
	assert.Equal(t,int64(95000),discProduct.Discount.ValueInCents,"Value with Discount should be equals to Expected")

}

func TestApplyDiscount_WhenIsBlackFriday(t *testing.T) {
	user := NewUser(time.Date(1990,time.November,1,1,2,3,4,time.UTC))
	product := NewProductWithoutDiscount()

	wayback := time.Date(time.Now().Year(), time.November, 25, 1, 2, 3, 4, time.UTC)
	patch := monkey.Patch(time.Now, func() time.Time { return wayback })
	defer patch.Unpatch()

	discProduct := applyDiscount(user,product)

	assert.Equal(t,int64(1000),discProduct.Discount.Pct, "Discount should be 10% because is BlackFriday")
	assert.Equal(t,int64(90000),discProduct.Discount.ValueInCents,"Value with Discount should be equals to Expected")

}

func TestApplyDiscount_WhenIsBlackFridayAndUserBirthday(t *testing.T) {
	user := NewUser(time.Date(1990,time.November,25,1,2,3,4,time.UTC))
	product := NewProductWithoutDiscount()

	wayback := time.Date(time.Now().Year(), time.November, 25, 1, 2, 3, 4, time.UTC)
	patch := monkey.Patch(time.Now, func() time.Time { return wayback })
	defer patch.Unpatch()

	discProduct := applyDiscount(user,product)

	assert.Equal(t,int64(1000),discProduct.Discount.Pct, "Discount should be 10% because is the limit for product pct")
	assert.Equal(t,int64(90000),discProduct.Discount.ValueInCents,"Value with Discount should be equals to Expected")
}

func NewProductWithoutDiscount() *model.Product {
	return &model.Product{
		Id: bson.NewObjectId(),
		Title: "ProductTitle",
		Description: "ProductDescription",
		PrinceInCents: int64(100000),
	}
}

func NewUser(birthday time.Time) *model.User {
	return &model.User{
		Id: bson.NewObjectId(),
		FirstName: "Marcos",
		LastName: "Batista",
		DateOfBirth: birthday,
	}
}