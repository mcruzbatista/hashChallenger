package grpc

import (
	"context"
	"google.golang.org/grpc"
	"google.golang.org/grpc/reflection"
	productGRPC "hashChallenger/delivery/grpc/product"
	"hashChallenger/model"
	_usecase"hashChallenger/usecase"
	"log"
)

type server struct {
	usecase _usecase.ProductUsecase
}

func NewProductServerGrpc(gserver *grpc.Server, productUcase _usecase.ProductUsecase) {

	productServer := &server{
		usecase: productUcase,
	}

	productGRPC.RegisterProductServiceServer(gserver, productServer)
	reflection.Register(gserver)
}

func (s *server) transformToRPC(prod *model.Product) *productGRPC.Product {
	if prod == nil {
		return nil
	}

	disc := &productGRPC.Discount{
		Pct:prod.Discount.Pct,
		ValueInCents:prod.Discount.ValueInCents,
	}

	resp := &productGRPC.Product{
		Id: prod.Id.Hex(),
		PrinceInCents: prod.PrinceInCents,
		Title: prod.Title,
		Description: prod.Description,
		Discount: disc,
	}
	return resp
}

func (s *server) FindAll(ctxt context.Context,prodReq *productGRPC.ProductRequest) (*productGRPC.ProductList, error) {
	var product_id, user_id string

	if prodReq != nil {
		product_id = prodReq.ProductId
		user_id = prodReq.UserId
	}

	list, err := s.usecase.GetProductByIdAndUserId(product_id,user_id)

	if err != nil {
		log.Printf(`ERROR:[%s]`, err.Error())
		return nil,err
	}

	 prodList := make([]*productGRPC.Product, len(list))
	for i,prod := range list {
		prodGRPC := s.transformToRPC(prod)
		prodList[i] = prodGRPC
	}

	result := &productGRPC.ProductList{
		Products:prodList,
	}

	return result, nil
}

