package repository

import (
	"github.com/globalsign/mgo"
	"github.com/globalsign/mgo/bson"
	"hashChallenger/model"
)

type userResource struct {
	session *mgo.Session
}

func (ur *userResource) FindUserById(userId string) (*model.User,error) {
	user := new(model.User)

	if err := ur.getCollection().FindId(bson.ObjectIdHex(userId)).One(user); err != nil {
		return nil,err
	}

	return user,nil
}

func NewUserRepository(session *mgo.Session) UserRepository {
	return &userResource{
		session:session,
	}
}

func (ur *userResource) getCollection() *mgo.Collection {
	return ur.session.DB("hash").C("user")
}