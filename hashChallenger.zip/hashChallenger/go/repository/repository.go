package repository

import "hashChallenger/model"

type ProductRepository interface {
	FindProductById(productId string) ([]*model.Product,error)
}

type UserRepository interface {
	FindUserById(userId string) (*model.User,error)
}
