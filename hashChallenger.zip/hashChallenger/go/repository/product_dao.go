package repository

import (
	"github.com/globalsign/mgo"
	"github.com/globalsign/mgo/bson"
	"hashChallenger/model"
)

type productResource struct {
	session *mgo.Session
}

func (pr *productResource) FindProductById(productId string) ([]*model.Product,error) {
	var query bson.M
	list := []*model.Product{}

	if productId != "" {
		query = bson.M{
			 "_id":bson.ObjectIdHex(productId),
		}
	}


	if err := pr.getCollection().Find(query).All(&list); err != nil {
		return nil,err
	}

	return list,nil
}

func NewProductRepository(session *mgo.Session) ProductRepository {
	return &productResource{
		session:session,
	}
}

func (pr *productResource) getCollection() *mgo.Collection {
	return pr.session.DB("hash").C("product")
}
