package mongoDB

import (
	"github.com/globalsign/mgo"
	"log"
)
var (
	Session *mgo.Session
)
func MongoDBConnect(url string) {

	if len(url) == 0 {
		panic("Can`t start because mongo uri is empty")
	}

	session,err := mgo.Dial(url)

	if err != nil {
		log.Printf(`ERROR:[%s]`,err)
		panic("Can`t connect to MongoDB")
	}else {
		log.Print("Connected with MongoDB")
	}

	session.SetMode(mgo.Monotonic, true)

	Session = session
}