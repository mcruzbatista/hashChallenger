package injection

import (
	"github.com/karlkfi/inject"
	"hashChallenger/repository"
	"hashChallenger/resource/database/mongoDB"
	"hashChallenger/usecase"
)

var (
	graph inject.Graph
	ProductRepo repository.ProductRepository
	UserRepo repository.UserRepository
	Usecase usecase.ProductUsecase

)

func Inject() {

	graph = inject.NewGraph()

	graph.Define(&Usecase, inject.NewProvider(usecase.NewProductService,&ProductRepo,&UserRepo))

	graph.Define(&ProductRepo, inject.NewProvider(repository.NewProductRepository,&mongoDB.Session))
	graph.Define(&UserRepo, inject.NewProvider(repository.NewUserRepository,&mongoDB.Session))

	graph.ResolveAll()
}
