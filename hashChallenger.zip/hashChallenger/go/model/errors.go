package model

import "errors"

var(
	ERROR_EMPTY_VALUES = errors.New("Empty values, please check your request params")
	ERROR_INVALID_VALUE = errors.New("Please check your request params, invalid params")
)