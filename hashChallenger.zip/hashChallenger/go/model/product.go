package model

import "github.com/globalsign/mgo/bson"

type Product struct {
	Id  bson.ObjectId  `bson:"_id"`
	PrinceInCents int64 `bson:"princeInCents"`
	Title string  `bson:"title"`
	Description string `bson:"description"`
	Discount Discount `bson:"discount"`
}

type Discount struct {
	Pct int64 `bson:"pct"`
	ValueInCents int64 `bson:"valueInCents"`
}