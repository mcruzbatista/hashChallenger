package model

import (
	"github.com/globalsign/mgo/bson"
	"time"
)

type User struct {
	Id bson.ObjectId `bson:"_id"`
	FirstName string `bson:"firstName"`
	LastName string `bson:"lastName"`
	DateOfBirth time.Time `bson:"dateOfBirth"`
}