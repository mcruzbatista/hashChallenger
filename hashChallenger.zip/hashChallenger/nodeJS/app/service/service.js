var grpc = require('grpc');
var productProto = grpc.load(__dirname + '/product.proto');
var client = new productProto.products.ProductService("127.0.0.1:8080",grpc.credentials.createInsecure());

const _findAll = (request) => new Promise((resolve,reject) => {
    client.FindAll(request, (error,products) => {
        if(error){
            reject(error);
        }else {
            if(products.length === 0) {
                reject("Empty result");
            }
            resolve(products);
        }
    });
})


exports.findAll = (userId) => {
    var request = {user_id: userId};
    return _findAll(request);
};