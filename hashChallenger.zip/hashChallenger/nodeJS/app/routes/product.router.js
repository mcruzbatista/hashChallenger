module.exports = (app) => {
    const controller = require('../controller/product.controller.js');

    // Retrieve all Product with userDiscount
    app.get('/product', controller.findAll);
}