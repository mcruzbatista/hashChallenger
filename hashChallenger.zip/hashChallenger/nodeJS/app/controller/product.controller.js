const Product = require('../model/product.model.js');
const service = require('../service/service.js');

exports.findAll = async (req,res) => {
    userId = req.headers['x-user-id']
    if (userId === undefined || userId.length === 0){
        res.status(400).send({
            message: "No userId on request header "
        }); 
    }
    try {
        products = await service.findAll(userId);
        res.send(products)
    } catch(e) {
        Product.find({},(err,products) => {
          if(err){
              res.send(400).send({
                  message:"Error on database to find products"
              })
          }else{
            res.send(products)
          } 
        })
    }
};