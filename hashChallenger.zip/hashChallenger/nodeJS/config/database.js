module.exports = {
    url: 'mongodb://hashuser:hash123@ds149593.mlab.com:49593/hash'
}
